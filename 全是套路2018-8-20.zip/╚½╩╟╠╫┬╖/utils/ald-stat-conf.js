exports.app_key = "fca225a650aab597ee461705f3a5f5b7"; //请在此行填写从阿拉丁后台获取的appkey
exports.getLocation = false; //默认不获取用户坐标位置
exports.appid = "wx675b2704c50f7e33"; //用于用户登录、微信转发群信息、二维码等微信官方功能
exports.appsecret = "5225ea12213711bcbe2904ec0567721d";//用于用户登录、微信转发群信息、二维码等微信官方功能
exports.defaultPath = 'pages/index/index';//小程序的默认首页, 用于分享时path为空时
