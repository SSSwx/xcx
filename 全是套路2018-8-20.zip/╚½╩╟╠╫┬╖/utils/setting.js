//基础配置
let _config = {
    host: 'https://wx.sanshengshi.ltd',
    imgHost: 'https://xcxoss.sanshengshi.ltd/pub/static',
    xcx: 153,
    shareData: [{
        shareTitle: '我天！原来隔壁老王套路都是在这学的',
        shareImg: 'tl_share_1.png'
    }, {
        shareTitle: '套路？车站嫩模玩套路，现场惊起一片欢呼...',
        shareImg: 'tl_share_2.png'
    }, {
        shareTitle: '震惊！套路老司机在这里轻松晋级为套路之王',
        shareImg: 'tl_share_3.png'
    }, {
        shareTitle: '你的套路多深，爱我就有多真！',
        shareImg: 'tl_share_4.png'
    }, {
        shareTitle: '美女深夜酒吧买醉，玩的不是刺激，玩的是套路~',
        shareImg: 'tl_share_5.png'
    }],
    v: '1.0.3',
    boxName: '脑筋急转弯套路版'
}

module.exports = _config;