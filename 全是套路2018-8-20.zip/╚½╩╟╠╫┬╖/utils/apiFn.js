const _setting = require("./setting.js")
const promise = require("./es6-promise.js");
const app = getApp();
let _fn = {
    request(url, data) {
        return new Promise((resolve, reject) => {
            data = Object.assign({
                xcx: _setting.xcx,
                cachekey: app.setConfig.cachekey
            }, data)
            // console.log(data)
            wx.request({
                url: `${_setting.host}/${url}`,
                data: data,
                method: 'POST',
                dataType: 'json',
                success: res => {
                    wx.hideLoading();
                    if (res.statusCode == 200) {
                        return resolve(res);
                    } else {
                        this.hideLoading();
                        this.showError({content:'出问题了哦~'});
                        return reject(res);
                    }
                },
                fail: res => {
                    this.showError();
                    return reject(res);
                }
            })
        })
    },
    requestFail(str = '你的网络开小差了哦') {
        wx.hideLoading();
        wx.showModal({
            title: '提示',
            content: str,
            showCancel: false,
            confirmText: '我知道了',
            confirmColor: "#DC143C"
        })
    },
    showError(t) {
        wx.hideLoading();
        return new Promise(function(resolve, reject) {
            t = Object.assign({
                    title: "",
                    content: "你的网络开小差了哦",
                    confirmText: "确定",
                    showCancel: !1,
                    confirmColor: "#DC143C",
                    success: function(t) {
                        t.confirm && resolve();
                    },
                    fail: function() {
                        reject();
                    }
                }, t),
                wx.showModal(t);
        });
    },
    showSuccess(t) {
        return new Promise(function(resolve, reject) {
            t = Object.assign({
                title: "",
                content: "操作成功",
                showCancel: !1,
                confirmText: "确定",
                confirmColor: "#DC143C",
                success: function(t) {
                    t.confirm && resolve();
                },
                fail: function() {
                    reject();
                }
            }, t), wx.showModal(t);
        });
    },
    hideLoading() {
        setTimeout(function() {
            wx.hideToast();
        }, 10);
    },
    showModel(t) {
        return new Promise(function(resolve, reject) {
            t = Object.assign({
                title: "标题",
                content: "",
                showCancel: !1,
                confirmText: "确定",
                success: function(t) {
                    t.confirm && resolve();
                },
                fail: function() {
                    reject();
                }
            }, t), wx.showModal(t);
        });
    },

    showLoading(t) {
        t = Object.assign({
            title: '加载中',
            mask: true,
        }, t), wx.showLoading(t);
    },
    showTip(t) {
        wx.showToast(Object.assign({
            title: '提示',
            icon: 'success',
            duration: 1000,
            mask: true
        }, t))
    },
    getArrRondomValue(arr) {
        return arr[parseInt(Math.random() * arr.length)];
    },
    getRondomNum(arr) {
        return parseInt(Math.random() * arr.length)
    },
    isEmptyObject: function(t) {
        for (var n in t) return !1;
        return !0;
    },
    charge(selectList, answer) {
        return new Promise((resolve, reject) => {
            let str = '';
            selectList.forEach((currentValue, index) => {
                str = `${str}${currentValue.content}`
            });
            if (str == answer) {
                resolve(1);
            } else {
                resolve(0);
            }
        })

    },
    countGlod(countNum, _this, type) {
        app.globalData.glodNum += countNum;
        _this.setData({
            glodNum: app.globalData.glodNum
        });
        wx.setStorageSync('glodNum', app.globalData.glodNum);
        if (type == 'share') {
            let today = app.getToday()
            app.globalData.shareNum = wx.getStorageSync(today) || 0;
            app.globalData.shareNum++;
            wx.setStorageSync(today, app.globalData.shareNum);
        }
    },
    collectionSetStorage(collectArr) {
        wx.setStorageSync('collection', JSON.stringify(collectArr));
    },


}
module.exports = _fn;