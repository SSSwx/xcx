// pages/ranking/ranking.js
const _apiFn = require("../../utils/apiFn");
const _setting = require("../../utils/setting");
const app = getApp();
Page({

    /**
     * 页面的初始数据
     */
    data: {
        threeList: [],
        userDataList: [],
        userData: {
            user_img: '',
            user_name: '',
            level: '',
            level_num: 1
        }
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        let _this = this;
        _this.threeList = [];
        _this.userDataList = [];
        wx.showShareMenu({
            withShareTicket: true
        })
        wx.getUserInfo({
            success: res => {
                if (res.userInfo.nickName.length >= 8) {
                    res.userInfo.nickName = res.userInfo.nickName.substring(0, 8);
                }
                _this.setData({
                    ['userData.avatarUrl']: res.userInfo.avatarUrl,
                    ['userData.nickName']: res.userInfo.nickName,
                })
                let userLevel = wx.getStorageSync('userLevel') || 0;
                if (userLevel != 0) {
                    let obj = {};
                    obj = JSON.parse(userLevel);
                }
                _this.loadData();
            }
        })
    },
    loadData() {
        wx.showLoading()
        let _this = this;
        _this.threeList.length = 0;
        _this.userDataList.length = 0;
        _apiFn.request('index/tricks/rank.html')
            .then(res => {
                _this.setData({
                    ['userData.level']: res.data.my.level,
                    ['userData.level_num']: res.data.my.level_num
                })
                res.data.list.forEach((currentValue, index) => {
                    if (currentValue.user_name.length >= 8) {
                        currentValue.user_name = currentValue.user_name.substring(0, 8);
                    }

                })
                if (res.data.list.length >= 3) {
                    for (let i = 0; i < 3; i++) {
                        _this.threeList[_this.threeList.length] = res.data.list.shift();
                    }
                    _this.userDataList = res.data.list;
                } else {
                    _this.threeList = res.data.list;
                }
                _this.setData({
                    threeList: _this.threeList,
                    userDataList: _this.userDataList
                })
                wx.stopPullDownRefresh();
            })
    },
    onPullDownRefresh: function() {
        this.loadData();
    },
    onShareAppMessage: function(res) {
        var that = this;
        let shareObj = _apiFn.getArrRondomValue(_setting.shareData);
        return {
            title: shareObj.shareTitle,
            path: `/pages/index/index?from=share&cachekey=${app.setConfig.cachekey}`,
            imageUrl: _setting.imgHost + '/' + shareObj.shareImg,
            complete: function(res) {
                if (app.globalData.shareNum < 5) {
                    if (res.errMsg == 'shareAppMessage:ok') {
                        //判断是否分享到群
                        if (res.hasOwnProperty('shareTickets')) {
                            //分享到群
                            _apiFn.showTip({
                                title: '获得60金币',
                                image: '/pages/images/glod.png'
                            });
                            _apiFn.countGlod(60, that, 'share');
                            that.data.isshare = 1;
                        } else {
                            // 分享到个人
                            _apiFn.countGlod(30, that, 'share');
                            _apiFn.showTip({
                                title: '获得30金币',
                                image: '/pages/images/glod.png'
                            });
                            that.data.isshare = 0;
                        }
                    } else {
                        wx.showToast({
                            title: '分享给别人可以获得金币哦',
                            icon: 'none'
                        })
                        that.data.isshare = 0;
                    }
                } else {
                    wx.showToast({
                        title: '一天只有五次机会哦',
                        icon: 'none'
                    })
                }

            },
        }
    },
})