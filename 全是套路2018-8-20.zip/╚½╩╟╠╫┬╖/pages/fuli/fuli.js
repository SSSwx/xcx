// pages/fuli/fuli.js
const _apiFn = require("../../utils/apiFn");
const _setting = require("../../utils/setting");
const app = getApp();
let shareList = [];
Page({

    /**
     * 页面的初始数据
     */
    data: {
        shareList: [{
                header_url: '/pages/images/jiahaoyou.png',
                prizeType: 1,
                prize: 20,
                receive: 1
            }, {
                header_url: '/pages/images/jiahaoyou.png',
                prizeType: 1,
                prize: 20,
                receive: 1
            }, {
                header_url: '/pages/images/jiahaoyou.png',
                prizeType: 2,
                prize: 1,
                receive: 1
            },
            {
                header_url: '/pages/images/jiahaoyou.png',
                prizeType: 1,
                prize: 30,
                receive: 1
            },
            {
                header_url: '/pages/images/jiahaoyou.png',
                prizeType: 1,
                prize: 40,
                receive: 1
            },
            {
                header_url: '/pages/images/jiahaoyou.png',
                prizeType: 1,
                prize: 40,
                receive: 1
            },
            {
                header_url: '/pages/images/jiahaoyou.png',
                prizeType: 1,
                prize: 50,
                receive: 1
            },
            {
                header_url: '/pages/images/jiahaoyou.png',
                prizeType: 2,
                prize: 1,
                receive: 1
            },
            {
                header_url: '/pages/images/jiahaoyou.png',
                prizeType: 1,
                prize: 60,
                receive: 1
            },
            {
                header_url: '/pages/images/jiahaoyou.png',
                prizeType: 1,
                prize: 60,
                receive: 1
            },
            {
                header_url: '/pages/images/jiahaoyou.png',
                prizeType: 1,
                prize: 70,
                receive: 1
            },
            {
                header_url: '/pages/images/jiahaoyou.png',
                prizeType: 1,
                prize: 70,
                receive: 1
            },
            {
                header_url: '/pages/images/jiahaoyou.png',
                prizeType: 1,
                prize: 70,
                receive: 1
            },
            {
                header_url: '/pages/images/jiahaoyou.png',
                prizeType: 1,
                prize: 70,
                receive: 1
            },
            {
                header_url: '/pages/images/jiahaoyou.png',
                prizeType: 2,
                prize: 1,
                receive: 1
            },
            {
                header_url: '/pages/images/jiahaoyou.png',
                prizeType: 1,
                prize: 80,
                receive: 1
            },
            {
                header_url: '/pages/images/jiahaoyou.png',
                prizeType: 1,
                prize: 80,
                receive: 1
            },
            {
                header_url: '/pages/images/jiahaoyou.png',
                prizeType: 1,
                prize: 80,
                receive: 1
            },
            {
                header_url: '/pages/images/jiahaoyou.png',
                prizeType: 1,
                prize: 80,
                receive: 1
            },
            {
                header_url: '/pages/images/jiahaoyou.png',
                prizeType: 1,
                prize: 80,
                receive: 1
            },
            {
                header_url: '/pages/images/jiahaoyou.png',
                prizeType: 1,
                prize: 90,
                receive: 1
            },
            {
                header_url: '/pages/images/jiahaoyou.png',
                prizeType: 1,
                prize: 90,
                receive: 1
            },
            {
                header_url: '/pages/images/jiahaoyou.png',
                prizeType: 1,
                prize: 90,
                receive: 1
            },
            {
                header_url: '/pages/images/jiahaoyou.png',
                prizeType: 1,
                prize: 90,
                receive: 1
            },
            {
                header_url: '/pages/images/jiahaoyou.png',
                prizeType: 1,
                prize: 90,
                receive: 1
            },
            {
                header_url: '/pages/images/jiahaoyou.png',
                prizeType: 1,
                prize: 100,
                receive: 1
            },
            {
                header_url: '/pages/images/jiahaoyou.png',
                prizeType: 1,
                prize: 100,
                receive: 1
            },
            {
                header_url: '/pages/images/jiahaoyou.png',
                prizeType: 1,
                prize: 100,
                receive: 1
            },
            {
                header_url: '/pages/images/jiahaoyou.png',
                prizeType: 1,
                prize: 100,
                receive: 1
            },
            {
                header_url: '/pages/images/jiahaoyou.png',
                prizeType: 1,
                prize: 100,
                receive: 1
            }
        ]
    },
    onLoad: function(options) {
        if (app.globalData.adv) {
            this.setData({
                adv: app.globalData.adv
            })
        }
        let _this = this;
        _this.loadData();
        wx.showShareMenu({
            withShareTicket: true
        })
    },
    loadData() {
        wx.showLoading()
        let _this = this;
        shareList = this.data.shareList;
        _apiFn.request('event/user/sharelist.html')
            .then(res => {
                _this.setData({
                    shareLength: res.data.list.length
                })
                res.data.list.forEach((currentValue, index) => {
                    currentValue = Object.assign(shareList[index], currentValue);
                })
                _this.setData({
                    shareList
                })
                wx.stopPullDownRefresh();
            })
    },
    onPullDownRefresh: function() {
        this.loadData();
    },
    showMask() {
        this.setData({
            showMask: true
        })
    },
    hideMask() {
        this.setData({
            showMask: false
        })
    },
    lingqu(e) {
        let _this = this;
        switch (e.currentTarget.dataset.receive) {
            case 0:
                wx.showLoading();
                _apiFn.request('event/user/receive.html', {
                        id: e.currentTarget.dataset.id
                    })
                    .then(res => {
                        wx.hideLoading();
                        if (res.data.status == 1) {
                            // 领取成功
                            switch (shareList[e.currentTarget.dataset.index].prizeType) {
                                case 1: //奖励金币
                                    _apiFn.countGlod(shareList[e.currentTarget.dataset.index].prize, _this);
                                    _apiFn.showTip({
                                        title: `获得${shareList[e.currentTarget.dataset.index].prize}金币`,
                                        image: '/pages/images/glod.png'
                                    })
                                    break;
                                case 2: //奖励转盘次数
                                    let lottery = wx.getStorageSync('lottery') || 0;
                                    wx.setStorageSync('lottery', +lottery + 1);
                                    _apiFn.showTip({
                                        title: `获得抽奖${shareList[e.currentTarget.dataset.index].prize}次`,
                                        image: '/pages/images/xzp.png'
                                    })
                                    break;
                                default:
                                    break;
                            }
                            shareList[e.currentTarget.dataset.index].receive = 2;
                            _this.setData({
                                shareList
                            })
                        }
                    })
                break;
            case 1:
                _apiFn.showTip({
                    title: `邀请好友才能获得金币哦！`,
                    icon: 'none'
                });
                break;
            case 2:
                _apiFn.showTip({
                    title: `已经领过了`,
                    icon: 'none'
                });
                break;
            default:
                break;
        }
    },
    onShareAppMessage: function(res) {
        var that = this;
        let shareObj = _apiFn.getArrRondomValue(_setting.shareData);
        return {
            title: shareObj.shareTitle,
            path: `/pages/index/index?from=share&cachekey=${app.setConfig.cachekey}`,
            imageUrl: _setting.imgHost + '/' + shareObj.shareImg,
            complete: function(res) {
                if (app.globalData.shareNum < 5) {
                    if (res.errMsg == 'shareAppMessage:ok') {
                        //判断是否分享到群
                        if (res.hasOwnProperty('shareTickets')) {
                            //分享到群
                            _apiFn.showTip({
                                title: '获得60金币',
                                image: '/pages/images/glod.png'
                            });
                            _apiFn.countGlod(60, that, 'share');
                            that.data.isshare = 1;
                        } else {
                            // 分享到个人
                            _apiFn.countGlod(30, that, 'share');
                            _apiFn.showTip({
                                title: '获得30金币',
                                image: '/pages/images/glod.png'
                            });
                            that.data.isshare = 0;
                        }
                    } else {
                        wx.showToast({
                            title: '分享给别人可以获得金币哦',
                            icon: 'none'
                        })
                        that.data.isshare = 0;
                    }
                } else {
                    wx.showToast({
                        title: '一天只有五次机会哦',
                        icon: 'none'
                    })
                }

            },
        }
    },
})