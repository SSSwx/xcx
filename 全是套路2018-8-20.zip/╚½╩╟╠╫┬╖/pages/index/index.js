const _apiFn = require("../../utils/apiFn");
const _setting = require("../../utils/setting");
const app = getApp();
Page({
    data: {
        optiionsList: [{
            image: '/pages/images/start.png',
            url: "/pages/answer/answer?from=start"
        }, {
            image: '/pages/images/mrxt.png',
            url: "/pages/taolu/taolu"
        }],
        bottomList: [{
                url: '/pages/fn/fn',
                titleImg: 'fn1.png',
                image: 'fn.png'
            },
            {
                url: '/pages/ranking/ranking',
                titleImg: 'ranking1.png',
                image: 'ranking.png'
            },
            {
                url: '/pages/more/more',
                titleImg: 'more1.png',
                image: 'more.png'
            },
            {
                url: '/pages/fuli/fuli',
                titleImg: 'welfare1.png',
                image: 'welfare.png'
            }
        ],
        showWantGlod: false,
        showSup: false,
        showTuisong: false,
        adv: ''

    },
    onLoad: function(options) {
        if (options.from == 'share') {
            this.from = options.from;
            this.fromcachekey = options.cachekey
        }
        wx.showShareMenu({
            withShareTicket: true
        })
        app.globalData.glodNum = +wx.getStorageSync('glodNum') || 0;
        app.setConfig.cachekey = wx.getStorageSync('cachekey') || '';
        this.setData({
            glodNum: app.globalData.glodNum
        })
        // loadNav
        this.loadNav();
        this.loadAd();
    },
    loadAd() {
        let _this = this;
        wx.request({
            url: `${_setting.host}/index/xcxSite/index.html?xcx=${_setting.xcx}`,
            success: res => {
                _this.setData({
                    adv: res.data.adv
                })
                app.globalData.adv = res.data.adv;
            }
        })
    },
    loadNav() {
        wx.request({
            url: `${_setting.host}//index/xcxsite/list.html?xcx=${_setting.xcx}&type=1`,
            success: res => {
                console.log(res)
                if (res.data.status != 0) {
                    let data = {
                        appid: res.data[0].appid,
                        boxname: _setting.boxName,
                        position: '首页左上角',
                        jump_parse: res.data[0].jump_parse
                    }
                    this.setData({
                        navobj: res.data[0],
                        jump_parse: data
                    })
                }
            }
        })
    },
    onShow() {
        let showSup = wx.getStorageSync('showSup');
        if (showSup == '1') {
            this.setData({
                showSup: true
            })
        } else {
            this.setData({
                showSup: false
            })
        }
        if (this.data.glodNum != app.globalData.glodNum) {
            this.setData({
                glodNum: app.globalData.glodNum
            })
        }
    },
    onReady() {
        this.getglod = this.selectComponent("#getglod");
        if (!app.globalData.everyShare) {
            wx.navigateTo({
                url: '/pages/everyDay/everyDay',
            })
        }

    },
    shareData() {
        let _this = this;
        if (_this.from == 'share') {
            let data = {
                tocachekey: _this.fromcachekey,
                fromcachekey: app.setConfig.cachekey
            }
            _apiFn.request('event/user/share.html', data)
                .then(res => {

                })
        }
    },
    login(nav) {
        let _this = this;
        wx.login({
            success: res => {
                wx.request({
                    url: `${_setting.host}/event/user/logon.html`,
                    data: {
                        satins: _setting.xcx,
                        code: res.code
                    },
                    method: "POST",
                    header: {
                        'content-type': 'application/json'
                    },
                    success: function(data) {
                        app.setConfig.sessionId = data.data.session_id;
                        wx.getUserInfo({
                            success: user => {
                                wx.request({
                                    url: `${_setting.host}/event/user/logon.html`,
                                    data: {
                                        satins: _setting.xcx,
                                        encryptedData: user.encryptedData,
                                        iv: user.iv
                                    },
                                    method: "POST",
                                    header: {
                                        'content-type': 'application/json',
                                        "cookie": "PHPSESSID=" + app.setConfig.sessionId
                                    },
                                    success: function(res) {
                                        wx.hideLoading();
                                        if (res.data.status == 0) { //登录失败，重新登录 "4d1af6657de6141a600df78553a40e04"
                                            wx.showModal({
                                                title: '提示',
                                                content: '登录失败，请重新登录',
                                                confirmColor: '#DC143C',
                                                showCancel: false
                                            })
                                            return false;
                                        }
                                        if (res.data.status == 1) { //登录成功
                                            app.setConfig.cachekey = res.data.cachekey;
                                            wx.setStorageSync('cachekey', app.setConfig.cachekey);
                                            // //用户分享
                                            _this.shareData();
                                            wx.showToast({
                                                title: '登录成功',
                                                icon: 'success',
                                                success: res => {
                                                    _this.navSwitch(nav);
                                                }
                                            })
                                        }
                                    },
                                    fail: res => {
                                        wx.hideLoading();
                                        app.showModal('加载失败')
                                    }
                                })

                            }
                        })
                    },
                    fail: res => {
                        wx.hideLoading();
                        app.showModal('加载失败')
                    }
                })
            }
        })
    },
    navSwitch(nav) {
        if (nav == 'tuisong') {
            this.setData({
                showTuisong: true
            })
            wx.hideLoading();
            return false;
        }
        wx.navigateTo({
            url: nav,
            success: () => {
                wx.hideLoading();
            }
        })
    },
    getuserinfo(e) {
        let _this = this;
        _apiFn.showLoading();
        if (e.detail.userInfo) { //允许登录
            if (app.setConfig.cachekey != '') {
                _this.shareData();
                _this.navSwitch(e.currentTarget.dataset.url);

            } else {
                _apiFn.showLoading()
                _this.login(e.currentTarget.dataset.url);
            }

            return false;
            _apiFn.showLoading();
            // _apiFn.request('');
            // 拿到用户数据
            // setTimeout(() => {
            wx.hideLoading();

            // }, 500)
        } else { //不允许登录
            _apiFn.showTip({
                title: '只有登录才可以玩哦！',
                icon: 'none'
            })
        }
    },
    showGetglod() {
        this.getglod.showAlter();
    },
    tirggerWantGlod() {
        this.getglod.hideAlter();
    },
    onShareAppMessage: function(res) {
        var that = this;
        let shareObj = _apiFn.getArrRondomValue(_setting.shareData);
        return {
            title: shareObj.shareTitle,
            path: `/pages/index/index?from=share&cachekey=${app.setConfig.cachekey}`,
            imageUrl: _setting.imgHost + '/' + shareObj.shareImg,
            complete: function(res) {
                if (app.globalData.shareNum < 5) {
                    if (res.errMsg == 'shareAppMessage:ok') {
                        //判断是否分享到群
                        if (res.hasOwnProperty('shareTickets')) {
                            //分享到群
                            _apiFn.showTip({
                                title: '获得60金币',
                                image: '/pages/images/glod.png'
                            });
                            _apiFn.countGlod(60, that, 'share');
                            that.data.isshare = 1;
                        } else {
                            // 分享到个人
                            _apiFn.countGlod(30, that, 'share');
                            _apiFn.showTip({
                                title: '获得30金币',
                                image: '/pages/images/glod.png'
                            });
                            that.data.isshare = 0;
                        }
                    } else {
                        wx.showToast({
                            title: '分享给别人可以获得金币哦',
                            icon: 'none'
                        })
                        that.data.isshare = 0;
                    }
                } else {
                    wx.showToast({
                        title: '一天只有五次机会哦',
                        icon: 'none'
                    })
                }

            },
        }
    },
    onPullDownRefresh() {
        setTimeout(res => {
            wx.stopPullDownRefresh();
        }, 400)
    },
    formSubmit(e) {
        let _this = this;
        _apiFn.showTip({
            title: '获得200金币',
            image: '/pages/images/glod.png'
        });
        _apiFn.countGlod(200, _this);
        _this.setData({
            showSup: false,
            showTuisong: false
        })
        wx.setStorageSync('showSup', '0');
        let fromUrl = `${_setting.host}/event/message/addformid.html?xcx=${_setting.xcx}&fromid=${e.detail.formId}&cachekey=${app.setConfig.cachekey}`;
        wx.request({
            url: fromUrl,
            success: res => {},
            fail: res => {}
        })
    },
    hideTuisong() {
        this.setData({
            showTuisong: false
        })
    },
    navXiaomao(e) {
        console.log(this.data.navobj)
        let data = {
            appid: this.data.navobj.appid,
            position: '首页-更多游戏',
            boxname: _setting.boxName,
            appname: this.data.navobj.content,
            jump_parse: this.data.navobj.jump_parse
        }
        console.log(data)
        wx.navigateToMiniProgram({
            appId: this.data.navobj.jump_appid,
            extraData: data,
        })
    }
})