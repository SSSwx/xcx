// pages/lottery/lottery.js
const util = require("../../utils/util");
const _apiFn = require("../../utils/apiFn");
const _setting = require("../../utils/setting");
const app = getApp();
let people = [];
let timer;
let diaji = false;

Page({

    /**
     * 页面的初始数据
     */
    data: {
        dataItem: [{
                id: 1,
                title: '实物展示',
                yellow: false
            },
            {
                id: 2,
                title: '幸运转盘',
                yellow: true
            },
            {
                id: 3,
                title: '我的奖券',
                yellow: false
            }
        ],
        showPage: 2,
        prize: [{
                title: '50元话费',
                image: 'gift_1b.png'
            }, {
                title: '金龙鱼花生油（4L）',
                image: 'gift_2b.png'
            }, {
                title: '奥妙洗衣液（3Kg）',
                image: 'gift_3b.png'
            },
            {
                title: '50元京东购物卡',
                image: 'gift_4b.png'
            }
        ],
        turePrize: [{
            title: '50金币',
            coin: 50,
            deg: 1057,
            dur: 4000
        }, {
            title: '100金币',
            coin: 100,
            deg: 1237,
            dur: 4000
        }, {
            title: '200金币',
            coin: 200,
            deg: 1147,
            dur: 4000
        }, {
            title: '1000金币！',
            coin: 1000,
            deg: 1320,
            dur: 4000
        }],
        choujiang: ['50元话费', '50金币', '50金币', '50金币', '金龙鱼花生油（4L)！', '奥妙洗衣液（3Kg）!', '1000金币！', '50元京东购物卡', '100金币', '200金币', '200金币', '200金币'],
        animationData: {},
        tipList: [{
            id: 1,
            title: '通关每日最新讨论最高可获得2次抽奖资格',
            url: '/pages/answer/answer?from=mrtl',

        }, {
            id: 2,
            title: '好友福利每天最高可获得6次抽奖资格',
            url: '/pages/fuli/fuli'
        }],
        showTip: false,

    },

    /**
     * 生命周期函数--监听页面加载
     */
    getOneItem() {
        let data = {
            name: _apiFn.getArrRondomValue(util.name),
            prize: _apiFn.getArrRondomValue(this.data.choujiang)
        }
        data.name = data.name.substring(0, data.name.length - 1);
        return data;
    },
    onLoad: function(options) {
        wx.showShareMenu({
            withShareTicket: true
        })
        let lottery = wx.getStorageSync('lottery') || 0;
        this.setData({
            lottery
        })
        people.length = 0;
        for (let i = 0; i < 4; i++) {
            people[people.length] = this.getOneItem();
        }
        this.setData({
            people
        })
    },
    onReady: function() {

    },
    onShow: function() {
        let _this = this;
        timer = setInterval(() => {
            people.shift();
            people[people.length] = _this.getOneItem();

            _this.setData({
                people
            })
        }, 1000)
    },
    onHide: function() {
        clearInterval(timer)
    },
    onUnload: function() {
        clearInterval(timer)
    },
    onPullDownRefresh: function() {

    },
    onReachBottom: function() {

    },
    onShareAppMessage: function(res) {
        var that = this;
        let shareObj = _apiFn.getArrRondomValue(_setting.shareData);
        return {
            title: shareObj.shareTitle,
            path: `/pages/index/index?from=share&cachekey=${app.setConfig.cachekey}`,
            imageUrl: _setting.imgHost + '/' + shareObj.shareImg,
            complete: function(res) {
                if (app.globalData.shareNum < 5) {
                    if (res.errMsg == 'shareAppMessage:ok') {
                        //判断是否分享到群
                        if (res.hasOwnProperty('shareTickets')) {
                            //分享到群
                            _apiFn.showTip({
                                title: '获得60金币',
                                image: '/pages/images/glod.png'
                            });
                            _apiFn.countGlod(60, that, 'share');
                            that.data.isshare = 1;
                        } else {
                            // 分享到个人
                            _apiFn.countGlod(30, that, 'share');
                            _apiFn.showTip({
                                title: '获得30金币',
                                image: '/pages/images/glod.png'
                            });
                            that.data.isshare = 0;
                        }
                    } else {
                        wx.showToast({
                            title: '分享给别人可以获得金币哦',
                            icon: 'none'
                        })
                        that.data.isshare = 0;
                    }
                } else {
                    wx.showToast({
                        title: '一天只有五次机会哦',
                        icon: 'none'
                    })
                }

            },
        }
    },
    changeSelcet(e) {
        if (e.currentTarget.dataset.id != this.data.showPage) {
            let dataItem = this.data.dataItem;
            dataItem.forEach((currentValue, index) => {
                if (currentValue.id == e.currentTarget.dataset.id) {
                    currentValue.yellow = true;
                } else {
                    currentValue.yellow = false;
                }

            });
            this.setData({
                showPage: e.currentTarget.dataset.id,
                dataItem
            })
        }
    },
    choujiang() {
        if (this.data.lottery >= 1) { //才可以抽奖
            if (!diaji) {
                diaji = true;

                let lottery = this.data.lottery - 1;
                wx.setStorageSync('lottery', lottery);
                this.setData({
                    lottery
                })
                // 旋转
                let item = _apiFn.getArrRondomValue(this.data.turePrize);
                let animation = wx.createAnimation({
                    transformOrigin: "50% 50%",
                    duration: item.dur,
                    timingFunction: "ease-in-out",
                    delay: 0
                })
                animation.rotateZ(item.deg).step();
                this.setData({
                    animationData: {}
                })
                this.setData({
                    animationData: animation.export()
                })
                setTimeout(res => {
                    app.globalData.glodNum = +app.globalData.glodNum + item.coin;

                    wx.setStorageSync('glodNum', app.globalData.glodNum);
                    _apiFn.showTip({
                        title: `获得${item.title}`,
                        image: '/pages/images/glod.png'
                    })
                    wx.setStorageSync('lottery', lottery)
                    setTimeout(res => {
                        let animation1 = wx.createAnimation({
                            transformOrigin: "50% 50%",
                            duration: 0,
                            timingFunction: "ease-in-out",
                            delay: 0
                        })
                        animation1.rotateZ(0).step();
                        this.setData({
                            animationData: animation1.export()
                        })
                        diaji = false;
                    }, 1000)
                }, item.dur)

            } else {
                _apiFn.showTip({
                    title: '正在抽奖，请稍后',
                    icon: 'none'
                })
            }
        } else {
            this.setData({
                showTip: true
            })
        }

        // 可以连点问题\



    },
    nav(e) {
        if (e.currentTarget.dataset.id == 1) {
            wx.navigateTo({
                url: '/pages/answer/answer?from=mrtl',
            })
        } else {
            wx.redirectTo({
                url: '/pages/fuli/fuli',
            })
        }
    },
    hideTip() {
        this.setData({
            showTip: false
        })
    }
})