// pages/more/more.js
const _setting = require("../../utils/setting");
const _apiFn = require("../../utils/apiFn");
const app = getApp();
let appArr = [];
let page = 1;
Page({

    /**
     * 页面的初始数据
     */
    data: {
        appArr: []
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        if (app.globalData.adv) {
            this.setData({
                adv: app.globalData.adv
            })
        }
        this.getAppInfo();
        wx.showShareMenu({
            withShareTicket: true
        })
    },
    getAppInfo: function() {
        let that = this;
        wx.showLoading({
            title: '加载中...',
        })
        let appArrSt = wx.getStorageSync('appArr') || '0';
        if (appArrSt == '0') {
            wx.request({
                url: `${_setting.host}/index/xcxsite/list.html?page=${page}&xcx=${_setting.xcx}`,
                success: res => {
                    if (res.data.status == '0' || res.data.length == 0) {
                        wx.showToast({
                            title: '加载完毕',
                            icon: 'success'
                        })
                        return;
                    }
                    res.data.forEach((currentValue, index) => {
                        currentValue.isClick = false;
                        appArr[appArr.length] = currentValue;
                    })
                    that.setData({
                        appArr
                    })
                    wx.setStorageSync('appArr', appArr)
                    wx.hideLoading();
                    wx.stopPullDownRefresh();
                    page++;
                    wx.request({
                        url: `${_setting.host}/index/xcxsite/list.html?page=${page}&xcx=${_setting.xcx}`,
                        success: res => {
                            if (res.data.status == '0' || res.data.length == 0) {
                                wx.showToast({
                                    title: '加载完毕',
                                    icon: 'success'
                                })
                                return;
                            }
                            res.data.forEach((currentValue, index) => {
                                currentValue.isClick = false;
                                appArr[appArr.length] = currentValue;
                            })
                            that.setData({
                                appArr
                            })
                            wx.setStorageSync('appArr', appArr)
                            wx.hideLoading();
                            wx.stopPullDownRefresh();
                            page++;
                        },
                    })
                },
                fail: res => {
                    wx.hideLoading();
                }
            })

        } else {
            wx.hideLoading();
            appArr = appArrSt;
            that.setData({
                appArr: appArrSt
            })
        }

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {
        appArr.length = 0;
        wx.setStorageSync('appArr', '0')
        page = 1;
        console.log('sss')
        this.getAppInfo();
    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function(res) {
        var that = this;
        let shareObj = _apiFn.getArrRondomValue(_setting.shareData);
        return {
            title: shareObj.shareTitle,
            path: `/pages/index/index?from=share&cachekey=${app.setConfig.cachekey}`,
            imageUrl: _setting.imgHost + '/' + shareObj.shareImg,
            complete: function(res) {
                if (app.globalData.shareNum < 5) {
                    if (res.errMsg == 'shareAppMessage:ok') {
                        //判断是否分享到群
                        if (res.hasOwnProperty('shareTickets')) {
                            console.log('分享到群', res.shareTickets[0]);
                            //分享到群
                            _apiFn.showTip({
                                title: '获得60金币',
                                image: '/pages/images/glod.png'
                            });
                            _apiFn.countGlod(60, that, 'share');
                            that.data.isshare = 1;
                        } else {
                            // 分享到个人
                            _apiFn.countGlod(30, that, 'share');
                            _apiFn.showTip({
                                title: '获得30金币',
                                image: '/pages/images/glod.png'
                            });
                            that.data.isshare = 0;
                        }
                    } else {
                        wx.showToast({
                            title: '分享给别人可以获得金币哦',
                            icon: 'none'
                        })
                        that.data.isshare = 0;
                    }
                } else {
                    wx.showToast({
                        title: '一天只有五次机会哦',
                        icon: 'none'
                    })
                }

            },
        }
    },
    nav(e) {
        let _this = this;
        console.log(e.currentTarget.dataset.id)
        appArr.forEach((currentValue, index) => {
            console.log(currentValue)

            if (currentValue.id == e.currentTarget.dataset.id) {
                // 加金币
                let data = {
                    appid: currentValue.appid,
                    position: '推荐列表',
                    boxname: _setting.boxName,
                    appname: currentValue.content,
                    jump_parse: currentValue.jump_parse
                }
                console.log(currentValue)
                wx.navigateToMiniProgram({
                    appId: currentValue.jump_appid,
                    extraData: data,
                    success: function(res) {
                        if (!currentValue.isClick) {
                            _apiFn.countGlod(100, _this);
                            currentValue.isClick = true;
                            _apiFn.showTip({
                                title: `获得100金币`,
                                image: '/pages/images/glod.png'
                            });
                            _this.setData({
                                appArr
                            })
                            wx.setStorageSync('appArr', appArr)
                        }

                    },
                })

            }
        });
    }
})