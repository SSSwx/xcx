// pages/levelList/levelList.js
const _apiFn = require("../../utils/apiFn");
const _question = require("../../utils/question");
Page({

    /**
     * 页面的初始数据
     */
    data: {
        dataList: [],
        showPage:false
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        wx.showShareMenu({
            withShareTicket: true
        });
        _apiFn.showLoading();
        this.levelnum = options.levelnum;
        let dataList = [];
        _question.forEach((currentValue, index) => {
            if (currentValue.levelNum == this.levelnum) {
                dataList[dataList.length] = currentValue;
            }
        })

        let n = wx.getStorageSync('answerNum') || 0;
        dataList.forEach((currentValue, index) => {
            if (currentValue.id <= n + 1) {
                currentValue.isActive = true;
            } else {
                currentValue.isActive = false;
            }
        });
        this.setData({
            dataList,
            showPage:true
        })

        wx.hideLoading();

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {

    },

    goAnswer(e) {
        if (e.currentTarget.dataset.cannav) {
            wx.redirectTo({
                url: `/pages/answer/answer?from=levelList&id=${e.currentTarget.dataset.id}`,
            })
        } else {
            wx.showModal({
                title: '提示',
                content: '关卡还没激活哦',
            })
        }
    },
})