const app = getApp();
const _question = require("../../utils/question");
const _mr = require("../../utils/mr");
const _apiFn = require("../../utils/apiFn");
const _setting = require("../../utils/setting");
let dataList = [];
Page({

    /**
     * 页面的初始数据
     */
    data: {
        dataList: [],
        showMask: false,
        maskData: {}
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        this.loadData(app.getStorage())
        wx.showShareMenu({
            withShareTicket: true
        })
    },
    loadData(list = []) {
        console.log(list)
        dataList.length = 0;
        list.forEach((currentValue, index) => {
            if (currentValue <= 1000) {
                dataList[dataList.length] = _question[currentValue - 1];
            } else {
                dataList[dataList.length] = _mr[currentValue - 1001];
            }
        });
        this.setData({
            dataList,
            length: dataList.length
        })
        console.log(this.data.dataList)
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {

    },
    share(e) {
        console.log(e.currentTarget.dataset.id)

        dataList.forEach((currentValue, index) => {
            if (currentValue.id == e.currentTarget.dataset.id) {
                console.log(currentValue)
                this.setData({
                    maskData: currentValue,
                    showMask: true
                })
            }
        });
    },
    deleteCollection(e) {
        console.log(e.currentTarget.dataset.id);
        console.log(_mr[e.currentTarget.dataset.id - 1001])
        if (e.currentTarget.dataset.id > 1000) {
            _mr[e.currentTarget.dataset.id - 1001].collection = false;
        } else {
            _question[e.currentTarget.dataset.id - 1].collection = false;
        }
        let collectionList = app.getStorage();
        app.getStorage().forEach((currentValue, index) => {
            if (currentValue == e.currentTarget.dataset.id) {
                console.log(collectionList.splice(index, 1))
                this.loadData(collectionList);
                _apiFn.collectionSetStorage(collectionList)
                return false;
            }
        })
    },
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function(res) {
        var that = this;
        let shareObj = _apiFn.getArrRondomValue(_setting.shareData);
        return {
            title: shareObj.shareTitle,
            path: `/pages/index/index?from=share&cachekey=${app.setConfig.cachekey}`,
            imageUrl: _setting.imgHost + '/' + shareObj.shareImg,
            complete: function(res) {
                if (app.globalData.shareNum < 5) {
                    if (res.errMsg == 'shareAppMessage:ok') {
                        //判断是否分享到群
                        if (res.hasOwnProperty('shareTickets')) {
                            console.log('分享到群', res.shareTickets[0]);
                            //分享到群
                            _apiFn.showTip({
                                title: '获得60金币',
                                image: '/pages/images/glod.png'
                            });
                            _apiFn.countGlod(60, that, 'share');
                            that.data.isshare = 1;
                        } else {
                            // 分享到个人
                            _apiFn.countGlod(30, that, 'share');
                            _apiFn.showTip({
                                title: '获得30金币',
                                image: '/pages/images/glod.png'
                            });
                            that.data.isshare = 0;
                        }
                    } else {
                        wx.showToast({
                            title: '分享给别人可以获得金币哦',
                            icon: 'none'
                        })
                        that.data.isshare = 0;
                    }
                } else {
                    wx.showToast({
                        title: '一天只有五次机会哦',
                        icon: 'none'
                    })
                }

            },
        }
    },
    cancel() {
        this.setData({
            showMask: false
        })
    }
})