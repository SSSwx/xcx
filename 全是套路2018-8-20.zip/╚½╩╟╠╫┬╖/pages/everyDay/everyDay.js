// pages/everyDay/everyDay.js
const app = getApp();
const _apiFn = require("../../utils/apiFn");
const _setting = require("../../utils/setting");
let dayList = [];
Page({
    data: {
        dayList: [{
                day: '第一天',
                glod: 20,
                active: false
            },
            {
                day: '第二天',
                glod: 40,
                active: false
            }, {
                day: '第三天',
                glod: 60,
                active: false
            }, {
                day: '第四天',
                glod: 80,
                active: false
            }, {
                day: '第五天',
                glod: 100,
                active: false
            }, {
                day: '第六天',
                glod: 120,
                active: false
            }, {
                day: '第七天',
                glod: 140,
                active: false
            }
        ],
        everyShare: false
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        wx.showShareMenu({
            withShareTicket: true
        })
        if (app.globalData.everyShare == '1') {
            this.setData({
                everyShare: true
            })
        } else {
            this.setData({
                everyShare: false
            })
        }

        dayList = this.data.dayList;
        dayList.forEach((currentValue, index) => {
            if (index + 1 == app.globalData.day) {
                currentValue.active = true;
                this.setData({
                    glod: currentValue.glod * 3
                })
            } else {
                currentValue.active = false;
            }
        })
        this.setData({
            dayList
        })

    },
    onReady: function() {

    },
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function(e) {
        let _this = this;
        let shareObj = _apiFn.getArrRondomValue(_setting.shareData);
        if (e.from === 'button') {
            // 来自页面内转发按钮
            _this.data.shareBtn = true;
        } else {
            //来自右上角转发
            _this.data.shareBtn = false;
        }
        return {
            title: shareObj.shareTitle,
            path: `/pages/index/index?from=share&cachekey=${app.setConfig.cachekey}`,
            imageUrl: _setting.imgHost + '/' + shareObj.shareImg,
            complete: function(res) {
                if (!_this.data.everyShare) {
                    if (res.hasOwnProperty('shareTickets')) { //分享到群
                        _apiFn.showTip({
                            title: `获得${_this.data.glod}金币`,
                            image: '/pages/images/glod.png',

                        });
                        _apiFn.countGlod(+_this.data.glod, _this);
                        if (!_this.data.everyShare) {
                            _this.setData({
                                everyShare: true
                            })
                        }
                        app.globalData.everyShare = true;
                        wx.setStorageSync('everyShare', '1');
                        setTimeout(res => {
                            wx.navigateBack({
                                delta: 1
                            })
                        }, 1000)
                    } else {
                        _apiFn.showTip({
                            title: '只有分享到群才能获得金币哦',
                            icon: "none"
                        });
                    }
                } else {
                    _apiFn.showTip({
                        title: '今天已经分享过了',
                        icon: "none"
                    });
                }
            }
        }
    },
    navback(e) {
        if (e.currentTarget.dataset.tap == 'giveUp') {
            let gold = +this.data.glod / 3;
            _apiFn.showTip({
                title: `获得${gold}金币`,
                image: '/pages/images/glod.png',
            });
            _apiFn.countGlod(+gold, this);
            app.globalData.everyShare = true;
            wx.setStorageSync('everyShare', '1');
            setTimeout(res => {
                wx.navigateBack({
                    delta: 1
                })
            }, 1000)
        } else {
            wx.navigateBack({
                delta: 1
            })
        }
    }

})