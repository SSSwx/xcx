// pages/achievement/achievement.js.
const _apiFn = require("../../utils/apiFn");
const _question = require("../../utils/question");
const _setting = require("../../utils/setting");
const app = getApp();
let achiList = [];
let n = 0;
Page({

    /**
     * 页面的初始数据
     */
    data: {
        achiList: [{
            title: '初学乍练',
            levelNum: 1,
            showActive: false
        }, {
            title: '初窥门径',
            levelNum: 2,
            showActive: false
        }, {
            title: '略知一二',
            levelNum: 3,
            showActive: false
        }, {
            title: '粗懂皮毛',
            levelNum: 4,
            showActive: false
        }, {
            title: '半生不熟',
            levelNum: 5,
            showActive: false
        }, {
            title: '登堂入室',
            levelNum: 6,
            showActive: false
        }, {
            title: '略有小成',
            levelNum: 7,
            showActive: false
        }, {
            title: '鹤立鸡群',
            levelNum: 8,
            showActive: false
        }, {
            title: '青出于蓝',
            levelNum: 9,
            showActive: false
        }, {
            title: '融会贯通',
            levelNum: 10,
            showActive: false
        }, {
            title: '心领神会',
            levelNum: 11,
            showActive: false
        }, {
            title: '炉火纯青',
            levelNum: 12,
            showActive: false
        }, {
            title: '略有大成',
            levelNum: 13,
            showActive: false
        }, {
            title: '豁然贯通',
            levelNum: 14,
            showActive: false
        }, {
            title: '出类拔萃',
            levelNum: 15,
            showActive: false
        }, {
            title: '罕有敌手',
            levelNum: 16,
            showActive: false
        }, {
            title: '技冠群雄',
            levelNum: 17,
            showActive: false
        }, {
            title: '神乎其技',
            levelNum: 18,
            showActive: false
        }, {
            title: '出神入化',
            levelNum: 19,
            showActive: false
        }, {
            title: '傲视群雄',
            levelNum: 20,
            showActive: false
        }, {
            title: '登峰造极',
            levelNum: 21,
            showActive: false
        }]
    },
    dataLoad() {
        achiList.length = 0;
        achiList = this.data.achiList;
        n = wx.getStorageSync('answerNum') || 0;
        achiList.forEach((currentValue, index) => {
            if (currentValue.levelNum <= _question[n].levelNum) {
                currentValue.showActive = true
            } else {
                return false;
            }
        });
        this.setData({
            achiList
        });
    },
    onLoad: function(options) {
        if (app.globalData.adv) {
            this.setData({
                adv: app.globalData.adv
            })
        }
        this.dataLoad();
        wx.showShareMenu({
            withShareTicket: true
        })
    },
    onReady: function() {


    },
    onShow: function() {
        let x = wx.getStorageSync('answerNum') || 0;
        if (x != n) {
            this.dataLoad();
        }
    },
    goLevelList(e) {
        if (e.currentTarget.dataset.cannav) {
            wx.navigateTo({
                url: `/pages/levelList/levelList?levelnum=${e.currentTarget.dataset.levelnum}`,
            })
        } else {
            _apiFn.showTip({
                title: '请先完成激活'
            })
        }
    },
    onShareAppMessage: function(res) {
        var that = this;
        let shareObj = _apiFn.getArrRondomValue(_setting.shareData);
        return {
            title: shareObj.shareTitle,
            path: `/pages/index/index?from=share&cachekey=${app.setConfig.cachekey}`,
            imageUrl: _setting.imgHost + '/' + shareObj.shareImg,
            complete: function(res) {
                if (app.globalData.shareNum < 5) {
                    if (res.errMsg == 'shareAppMessage:ok') {
                        //判断是否分享到群
                        if (res.hasOwnProperty('shareTickets')) {
                            //分享到群
                            _apiFn.showTip({
                                title: '获得60金币',
                                image: '/pages/images/glod.png'
                            });
                            _apiFn.countGlod(60, that, 'share');
                            that.data.isshare = 1;
                        } else {
                            // 分享到个人
                            _apiFn.countGlod(30, that, 'share');
                            _apiFn.showTip({
                                title: '获得30金币',
                                image: '/pages/images/glod.png'
                            });
                            that.data.isshare = 0;
                        }
                    } else {
                        wx.showToast({
                            title: '分享给别人可以获得金币哦',
                            icon: 'none'
                        })
                        that.data.isshare = 0;
                    }
                } else {
                    wx.showToast({
                        title: '一天只有五次机会哦',
                        icon: 'none'
                    })
                }

            },
        }
    },
    onPullDownRefresh() {
        setTimeout(res => {
            wx.stopPullDownRefresh();
        }, 400)
    }
})