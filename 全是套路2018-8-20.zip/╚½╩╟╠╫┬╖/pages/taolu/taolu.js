// pages/taolu/taolu.js
const _apiFn = require("../../utils/apiFn");
const _mr = require("../../utils/mr");
const app = getApp();
Page({
    /**
     * 页面的初始数据
     */
    data: {
        dataList: [{
            image: 'mrxtl.png',
            id: 1,
            go: "answer",
            tipTitle: '挑战规则',
            tip: ['1、每日推出10道精选新题，全部通关后可获得一次“幸运转盘抽奖机会”', '2、通关后不可重复挑战！', '3、每日可使用提示上线五次'],
            url: '/pages/answer/answer?from=mrtl'
        }, {
            image: 'zp.png',
            id: 2,
            go: 'lottery',
            tipTitle: '幸运大转盘',
            tip: ['1、每次抽奖会消耗1次抽奖机会，当次数为0时不可抽奖', '2、通关每日新套路可获得2次抽奖次数！', '3、抽奖次数可以累积！', '4、抽奖有几率获得京东卡等实体奖励，当抽中时会得到一张奖券作为凭证（可在“我的奖券中查看”，发送奖券号给客服并留下收货地址，客服会将实物邮寄给您！）']
        }],
        tip: '',
        tipTitle: '',
        showMask: false,
        canAnswer: true,
        lottery: 0,
        url: '/pages/lottery/lottery'
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        let mr = JSON.parse(wx.getStorageSync('mr') || []);
        if (app.mr.length == 0) {
            mr.forEach((currentValue, index) => {
                app.mr[app.mr.length] = _mr[currentValue - 1001];
            })
        }

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {
        if (wx.getStorageSync('clearance')) { //同关了
            this.setData({
                canAnswer: false
            })
        } else { //没有通关
            this.setData({
                canAnswer: true
            })
        }
        let lottery = wx.getStorageSync('lottery') || 0;
        this.setData({
            lottery
        })
    },
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },
    openTip(e) {
        this.data.dataList.forEach((currentValue, index) => {
            if (currentValue.id == e.currentTarget.dataset.id) {
                this.setData({
                    tip: currentValue.tip,
                    tipTitle: currentValue.tipTitle,
                    showMask: true
                })
            }
        });
    },
    guanbi() {
        this.setData({
            showMask: false
        })
    },
    nav(e) {
        switch (e.currentTarget.dataset.go) {
            case 'answer':
                if (this.data.canAnswer) {
                    wx.navigateTo({
                        url: '/pages/answer/answer?from=mrtl',
                    })
                } else {
                    _apiFn.showTip({
                        title: '今天已经通关了！ '
                    })
                }

                break
            case 'lottery':
                wx.navigateTo({
                    url: '/pages/lottery/lottery',
                })
                break;
            default:
                break;
        }
    }
})