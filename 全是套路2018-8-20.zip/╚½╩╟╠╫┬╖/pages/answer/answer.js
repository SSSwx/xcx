//index.js
//获取应用实例
const _apiFn = require("../../utils/apiFn");
const _setting = require("../../utils/setting");
const _question = require("../../utils/question");
const _mr = require("../../utils/mr");
const app = getApp();
let answerList = [];
let selectList = [];
let n = 0;
let collectArr = [];
let collectAllNum = 50;

// let deductionNum = 40;
Page({
    data: {
        answerList: [],
        selectList: [],
        answer: '',
        showPage: false,
        question: '',
        mrtl: [],
        showdalibao: false,
        showMrzxTip: false,
        mrtl_share: 0,
        tipTime: '',
        adv: '',
        bigWidth: false,
        bigHeigth: false
    },
    dataLoad(n) {
        if (n >= 1000) {
            _apiFn.showTip({
                title: '恭喜通关'
            })
            setTimeout(() => {
                wx.navigateBack({
                    delta: 1
                })
            }, 1000)
        }
        answerList.length = 0;
        selectList.length = 0;
        // 请求数据
        let data;
        if (this.from == 'mrtl') {
            app.mr[n].isShow = true;
            data = app.mr[n];
            this.setData({
                mrtl: app.mr,
                index: n + 1
            })
        } else {
            data = _question[n];
            wx.setNavigationBarTitle({
                title: `【${data.level}】`,
            })
            let obj = {
                id: data.id,
                level: data.level,
                levelNum: data.level_n
            }
            wx.setStorageSync('userLevel', JSON.stringify(obj));
            _apiFn.request('index/tricks/answer.html', obj)
                .then(res => {})

        }
        // 数据处理
        for (let i = 0; i < data.selectStr.length; i++) {
            answerList[answerList.length] = {
                index: i,
                content: data.selectStr[i],
                isSelect: false
            }
        }
        for (let i = 0; i < data.answer.length; i++) {
            selectList.push({
                index: i,
                content: ''
            });
        }
        console.log(answerList.length)
        if (answerList.length > 9) {
            this.setData({
                bigWidth: true
            })
        } else {
            this.setData({
                bigWidth: false
            })
        }
        this.setdata();
        if (!this.data.showPage) {
            this.setData({
                showPage: true
            })
        }
        this.setData({
            data
        });
    },
    setdata() {
        this.setData({
            answerList,
            selectList,
        })
    },
    onLoad(e) {
        if (app.globalData.adv) {
            this.setData({
                adv: app.globalData.adv
            })
        }
        collectArr = app.getStorage();
        wx.showShareMenu({
            withShareTicket: true
        })
        this.from = e.from;
        switch (e.from) {
            case 'start':
                n = wx.getStorageSync('answerNum') || 0;
                this.dataLoad(n);
                break;
            case 'levelList':
                n = wx.getStorageSync('answerNum') || 0;
                this.levelListId = +e.id - 1;
                this.dataLoad(this.levelListId);
                break;
            case 'mrtl':
                this.setData({
                    bigHeigth: true
                })
                wx.setNavigationBarTitle({
                    title: '【每日最新套路】',
                })
                app.mr.forEach((currentValue, index) => {
                    if (index < app.globalData.mr_num) {
                        currentValue.isShow = true;
                    }
                });
                let tipTime = app.globalData.tipTime;
                this.setData({
                    mrtl: app.mr,
                    tipTime
                })
                this.mr_num = app.globalData.mr_num;
                this.dataLoad(this.mr_num);
                break;
            default:
                break;
        }
        let glodNum = wx.getStorageSync('glodNum') || 0;
        this.setData({
            glodNum
        })


    },
    answerSelect(e) {
        let _this = this;
        let index = e.currentTarget.dataset.index;
        if (!answerList[index].isSelect) { //如果没有选择
            let num = 0;
            for (let i = 0; i < selectList.length; i++) {
                if (selectList[i].content == '') {
                    num++;
                    selectList[i].content = answerList[index].content; //改变
                    selectList[i].answerindex = answerList[index].index; //改变
                    answerList[index].isSelect = true; //隐藏
                    _this.setdata();
                    let seletNum = 0;
                    selectList.forEach((currentValue, index) => {
                        if (currentValue.content == '') {
                            seletNum++;
                        }
                    })
                    console.log(seletNum)
                    if (seletNum == 0) { // 满了
                        //判断
                        _this.selectOver();
                    }
                    if (selectList[i].index == selectList.length - 1) {

                    }
                    return;
                }
            }
            if (num == 0) {
                _apiFn.showTip({
                    title: '先删除错误答案',
                    icon: 'none'
                })
            }

        }
    },
    selectOver() {
        let _this = this;
        _apiFn.charge(selectList, this.data.data.answer)
            .then(res => {
                if (res == 1) {
                    switch (_this.from) {
                        case 'start':
                            n++;
                            let data = _this.getDiffient();
                            _this.setData({
                                nextLevel: data
                            })
                            if (n % 5 == 0) {
                                this.setData({
                                    showdalibao: true
                                })
                            } else {
                                if (data.nextLevelNum == 0) { //获得新的称号，得到三倍金币奖励
                                    _this.setData({
                                        ['data.coin']: +_this.data.data.coin * 3
                                    })
                                    _apiFn.countGlod(+_this.data.data.coin, _this);

                                } else {
                                    _apiFn.countGlod(+_this.data.data.coin, _this);
                                }
                                console.log(n)
                                _this.alter.showAlter();
                            }
                            wx.setStorageSync('answerNum', n);
                            wx.setStorageSync('glodNum', app.globalData.glodNum);
                            break;
                        case 'levelList':

                            if (_this.levelListId >= n) {
                                this.levelListId++;
                                _apiFn.countGlod(+this.data.data.coin, _this);
                                wx.setStorageSync('answerNum', _this.levelListId);
                                wx.setStorageSync('glodNum', app.globalData.glodNum);
                            } else if (_this.levelListId < n) {
                                this.levelListId++;
                            }
                            _this.alter.showAlter();
                            break;
                        case 'mrtl':
                            this.mr_num++;
                            app.globalData.mr_num = this.mr_num;
                            wx.setStorageSync('mr_num', this.mr_num);
                            if (this.mr_num < 10) {
                                _this.alter.showAlter();
                            } else {
                                wx.setStorageSync('clearance', '1'); //今日已通关
                                // 抽奖券
                                let lottery = wx.getStorageSync('lottery') || 0;
                                wx.setStorageSync('lottery', +lottery + 2);
                                wx.showModal({
                                    title: '提示',
                                    content: '恭喜您答对了所有的题目，现送您两张抽奖券，快去抽奖吧',
                                    confirmText: "我知道了",
                                    showCancel: false,
                                    success: res => {
                                        if (res.confirm) {
                                            wx.navigateBack({
                                                delta: 1
                                            })
                                        }
                                    }
                                })
                            }

                            break;
                        default:
                            break
                    }

                } else {
                    console.log(_this.data.selectList)
                    _apiFn.showTip({
                        title: '回答错误',
                        icon: 'none',
                    })

                }

            })
    },
    selectCancel(e) {
        selectList.forEach((currentValue, index) => {
            if (currentValue.answerindex == e.currentTarget.dataset.answerindex && currentValue.content != '') {
                console.log(currentValue)
                let content = currentValue.content;
                answerList[e.currentTarget.dataset.answerindex].isSelect = false;
                currentValue.content = '';
                console.log(selectList, answerList)
                this.setData({
                    answerList,
                    selectList
                })
            }
        })
    },
    onReady() {
        this.alter = this.selectComponent("#alter");
        this.getglod = this.selectComponent("#getglod");
    },
    loadNext() {
        this.alter.hideAlter();
        switch (this.from) {
            case 'start':
                this.dataLoad(n);
                break;
            case 'levelList':
                this.dataLoad(this.levelListId);
                break;
            case 'mrtl':
                this.dataLoad(this.mr_num)
                break;
            default:
                break;
        }

    },
    getTipFn(flog = false, coin = 30) {
        let c = 0;
        if (this.data.glodNum < coin) { //金币不足
            this.getglod.showAlter();
            return false;
        }
        for (let i = selectList.length; i > 0; i--) {
            if (selectList[i - 1].content == '') {
                c++;
                if (this.data.glodNum >= coin) {
                    if (flog) { //传值的话不扣除金币

                    } else {
                        _apiFn.countGlod(-coin, this);
                    }

                    for (let j = 0; j < answerList.length; j++) {
                        if (answerList[j].content == this.data.data.answer[i - 1] && !answerList[j].isSelect) {
                            answerList[j].isSelect = true;
                            selectList[i - 1].content = answerList[j].content;
                            selectList[i - 1].answerindex = answerList[j].index;
                            this.setdata();
                            let x = 0;
                            selectList.forEach((value) => {
                                if (value.content == '') {
                                    x++;
                                }
                            })
                            if (x == 0) {
                                this.selectOver();

                            }
                            return false;
                        }
                    }

                    if (this.from == 'mrtl') { //
                        app.globalData.tipTime = +app.globalData.tipTime - 1;
                        this.setData({
                            tipTime: app.globalData.tipTime
                        })
                        wx.setStorageSync('tipTime', app.globalData.tipTime);
                    }
                    let x = 0;
                    for (let i = 0; i < selectList.length; i++) {
                        if (selectList[i].content == '') {
                            x++;
                        }
                        if (x === 0) {
                            this.selectOver();
                            return false;
                        }
                    }
                    return false;
                } else {}
            }

        }
        if (c === 0) {
            _apiFn.showTip({
                title: '请先删除错误答案',
                icon: 'none',
            })
        }
    },
    getTip() {
        switch (this.from) {
            case 'start':
                this.getTipFn();
                break;
            case 'levelList':
                this.getTipFn();
                break;
            case 'mrtl':
                if (this.data.tipTime <= 0) {
                    _apiFn.showTip({
                        title: '今天已经用完了5次机会哦',
                        icon: 'none'
                    })
                } else {
                    this.setData({
                        showMrzxTip: true
                    })
                }
                break;
            default:
                break;
        }
    },
    collect(e) {
        collectArr = app.getStorage();
        if (e.target.id == 'alter') {
            if (!e.detail.ifCollection) {
                if (collectArr.length < collectAllNum) {
                    collectArr[collectArr.length] = this.data.data.id;
                    this.setData({
                        ["data.collection"]: true
                    })
                    _apiFn.showTip({
                        title: '收藏成功'
                    })
                    _apiFn.collectionSetStorage(collectArr);
                } else {
                    _apiFn.showTip({
                        title: '你已经收藏50条了',
                        icon: 'none'
                    })
                }
            } else {
                _apiFn.showTip({
                    title: '你已经收藏过了',
                    icon: 'none'
                })
            }
        } else {
            if (!e.currentTarget.dataset.ifcollection) {
                if (collectArr.length < collectAllNum) {
                    collectArr[collectArr.length] = this.data.data.id;
                    this.setData({
                        ["data.collection"]: true
                    })
                    _apiFn.showTip({
                        title: '收藏成功'
                    })
                    _apiFn.collectionSetStorage(collectArr);
                } else {
                    _apiFn.showTip({
                        title: '你已经收藏50条了',
                        icon: 'none'
                    })
                }
            } else {
                _apiFn.showTip({
                    title: '你已经收藏过了',
                    icon: 'none'
                })
            }
        }

    },
    tirggerWantGlod() {
        this.getglod.hideAlter();
    },
    hidedalibao() {
        let _this = this;
        // 普通领取
        _apiFn.showTip({
            title: `获得${_this.data.data.coin}金币`,
            image: '/pages/images/glod.png'
        });
        _apiFn.countGlod(+_this.data.data.coin, _this);
        wx.setStorageSync('answerNum', n);
        wx.setStorageSync('glodNum', app.globalData.glodNum);
        _this.setData({
            showdalibao: false
        })
        _this.alter.showAlter();
    },
    getDiffient() {
        let data = {
            nextLevelNum: 0,
            nextLevelCh: this.data.data.level,
            isshow: true
        }
        for (let i = n; i < _question.length; i++) {
            if (data.nextLevelCh != _question[i].level) {
                data.nextLevelCh = _question[i].level;
                return data;
            } else {
                data.nextLevelNum++;
            }
        }
    },
    chargeShare() {
        _apiFn.showTip({
            title: "一天只能分享五次",
            icon: 'none',
            duration: 1000
        })
    },
    onShareAppMessage: function(e) {
        var _this = this;
        if (e.from === 'button') {
            // 来自页面内转发按钮
            _this.data.shareBtn = true;
        } else {
            //来自右上角转发
            _this.data.shareBtn = false;
        }
        let shareObj = _apiFn.getArrRondomValue(_setting.shareData);
        return {
            title: shareObj.shareTitle,
            path: `/pages/index/index?from=share&cachekey=${app.setConfig.cachekey}`,
            imageUrl: _setting.imgHost + '/' + shareObj.shareImg,
            complete: function(res) {
                // if (app.globalData.shareNum <= 5) {
                if (res.errMsg == 'shareAppMessage:ok') {
                    switch (e.from) {
                        case 'menu': //顶部
                            if (res.hasOwnProperty('shareTickets')) { //分享到群
                                if (app.globalData.shareNum <= 5) {
                                    _apiFn.showTip({
                                        title: '获得60金币',
                                        image: '/pages/images/glod.png'
                                    });
                                    _apiFn.countGlod(60, _this, 'share');
                                    _this.data.isshare = 1;
                                } else {
                                    _this.chargeShare();
                                }
                            } else { //分享到个人
                                if (app.globalData.shareNum <= 5) {
                                    _apiFn.countGlod(30, _this, 'share');
                                    _apiFn.showTip({
                                        title: '获得30金币',
                                        image: '/pages/images/glod.png'
                                    });
                                    _this.data.isshare = 0;
                                } else {
                                    _this.chargeShare();
                                }

                            }
                            break;
                        case 'button': //按钮分享
                            switch (e.target.dataset.share) {
                                case 'dalibao': //大礼包的分享点击
                                    if (res.hasOwnProperty('shareTickets')) { //从大礼包分享到群
                                        let coin = +_this.data.data.coin * 5;
                                        _apiFn.showTip({
                                            title: `获得${coin}金币`,
                                            image: '/pages/images/glod.png'
                                        });
                                        _apiFn.countGlod(+_this.data.data.coin * 5, _this);
                                        _this.setData({
                                            showdalibao: false
                                        })
                                        _this.alter.showAlter();
                                    } else { //从大礼包分享到个人
                                        _apiFn.showTip({
                                            title: '只有分享到群才可以获得5倍金币哦',
                                            icon: 'none'
                                        })
                                    }
                                    break;
                                case 'friend':
                                    if (res.hasOwnProperty('shareTickets')) { //分享到群
                                        if (app.globalData.shareNum <= 5) {
                                            _apiFn.showTip({
                                                title: '获得60金币',
                                                image: '/pages/images/glod.png'
                                            });
                                            _apiFn.countGlod(60, _this, 'share');
                                            _this.data.isshare = 1;
                                        } else {
                                            _this.chargeShare();
                                        }

                                    } else { //分享到个人
                                        if (app.globalData.shareNum <= 5) {
                                            _apiFn.countGlod(30, _this, 'share');
                                            _apiFn.showTip({
                                                title: '获得30金币',
                                                image: '/pages/images/glod.png'
                                            });
                                            _this.data.isshare = 0;
                                        } else {
                                            _this.chargeShare();
                                        }
                                    }
                                    break;
                                case 'getTip': //每日题的分享点击
                                    if (res.hasOwnProperty('shareTickets')) { //分享到群
                                        _apiFn.showTip({
                                            title: '获得60金币',
                                            image: '/pages/images/glod.png'
                                        })
                                        _apiFn.countGlod(60, _this);
                                    } else { //分享到个人
                                        _apiFn.showTip({
                                            title: '分享给个人可获得30金币，分享到群可获得60金币',
                                            icon: 'none'
                                        })
                                        _apiFn.countGlod(30, _this);
                                    }
                                    _this.setData({
                                        showMrzxTip: false,
                                        mrtl_share: 1
                                    })
                                    _this.getTipFn(true); //************************ */

                                    break;
                                default:
                                    break;
                            }
                            break;
                        default:
                            break;
                    }
                } else {
                    wx.showToast({
                        title: '分享给别人可以获得金币哦',
                        icon: 'none'
                    })
                }


            }
        }
    },
    showGetglod() {
        this.getglod.showAlter();
    },
    guanbi() {
        if (this.data.showMrzxTip) {
            this.setData({
                showMrzxTip: false
            })
        }
    },
    mrtl_getAnswer() {
        if (this.data.glodNum < 50) { //金币不足
            this.setData({
                mrtl_share: 2
            })
        } else {
            this.getTipFn(false, 50);
            this.setData({
                showMrzxTip: false
            })
        }
    },
    onPullDownRefresh() {
        setTimeout(res => {
            wx.stopPullDownRefresh();
        }, 400)
    }
})