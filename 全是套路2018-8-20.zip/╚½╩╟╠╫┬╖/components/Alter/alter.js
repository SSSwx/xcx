// components/Dialog/dialog.js
Component({
    options: {
        multipleSlots: true // 在组件定义时的选项中启用多slot支持
    },
    /**
     * 组件的属性列表
     * 用于组件自定义设置
     */
    properties: {
        // 弹窗标题
        answer: { // 属性名
            type: String, // 类型（必填），目前接受的类型包括：String, Number, Boolean, Object, Array, null（表示任意类型）
            value: '答案' // 属性初始值（可选），如果未指定则会根据类型选择一个
        },
        // 弹窗内容
        analysis: {
            type: String,
            value: '解析'
        },
        // 弹窗取消按钮文字
        question: {
            type: String,
            value: '问题'
        },
        data: {
            type: Object,
            value: {
                answer: '答案',
                analysis: "解析",
                question: '问题',
                icon: 20
            }
        },
        nextLevel: {
            type: Object,
            value: {
                nextLevelCh: '',
                nextLevelNum: 0
            }
        }

    },

    /**
     * 私有数据,组件的初始数据
     * 可用于模版渲染
     */
    data: {
        // 弹窗显示控制
        isShow: false,
        showQuestion: false
    },

    /**
     * 组件的方法列表
     * 更新属性和数据的方法与更新页面数据的方法类似
     */
    methods: {
        /*
         * 公有方法
         */

        //隐藏弹框
        hideAlter() {
            this.setData({
                isShow: false
            })
        },
        //展示弹框
        showAlter() {
            this.setData({
                isShow: true
            })
        },
        touchstart() {
            this.setData({
                showQuestion: true
            })
        },
        touchend() {
            this.setData({
                showQuestion: false
            })
        },
        h_alter() {
            this.setData({
                isShow: false
            })
        },
        /*
         * 内部私有方法建议以下划线开头
         * triggerEvent 用于触发事件
         */
        _goNext() {
            this.triggerEvent('goNext');
        },
        _cancelEvent() {
            //触发取消回调
            console.log('点击取消');
            // this.hideDialog();
            this.triggerEvent("cancelEvent", {
                sss: 'ssss'
            })
        },
        _confirmEvent() {
            //触发成功回调
            console.log('点击确定');
            this.triggerEvent("confirmEvent");
        },
        _collect(e){
            console.log(e)
            this.triggerEvent("collect", {
                ifCollection: e.currentTarget.dataset.ifcollection
            });
        }
    }
})