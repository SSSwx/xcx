//app.js
var aldstat = require("./utils/ald-stat.js");
let _question = require("./utils/question");
let _mr = require("./utils/mr");
App({
    onLaunch: function(opt) {
        this.chargeNewDay();
        this.dataSynchronize();
        if (this.globalData.newDay) {
            // 随机每日最新套路题库
            wx.setStorageSync('showSup', '1');
            this.globalData.showSup = '1';
            this.globalData.day = +wx.getStorageSync('day') || 0;
            this.globalData.day = this.globalData.day + 1;
            if (this.globalData.day > 7) this.globalData.day = 1;
            wx.setStorage({
                key: 'day',
                data: this.globalData.day
            })
            wx.removeStorageSync('clearance');
            wx.removeStorageSync('appArr');
            wx.removeStorageSync('everyShare'); 
            wx.removeStorageSync('tipTime');
            let mr = JSON.stringify(this.random(10, 1001, 1240))
            wx.setStorageSync('mr', mr);
        } else { //第一天接着玩
            this.globalData.day = +wx.getStorageSync('day');
            this.globalData.mr_num = wx.getStorageSync('mr_num') || 0;
            this.globalData.shareNum = wx.getStorageSync(this.getToday()) || 0;
            this.globalData.everyShare = wx.getStorageSync('everyShare') || 0;
            this.globalData.tipTime = wx.getStorageSync('tipTime') || 5;
        }
    },
    globalData: {
        userInfo: null,
        glodNum: 0,
        newDay: false,
        shareNum: 0,
        mr_num: 0,
        everyShare: false,
        tipTime: 5
    },
    setConfig: {
        sessionId:'',
        cachekey:''
    },
    mr: [],
    getStorage() {
        let arr = wx.getStorageSync('collection') || '[]';
        return JSON.parse(arr);
    },
    dataSynchronize() { //数据同步
        let collectionArr = this.getStorage();
        collectionArr.forEach((currentValue, index) => {
            if (currentValue <= 1000) {
                _question[currentValue - 1].collection = true;
            } else {
                _mr[currentValue - 1001].collection = true;
            }
        })
    },
    getToday() {
        const date = new Date();
        return date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate();
    },
    chargeNewDay() {
        let lastDay = wx.getStorageSync('lastDay') || 1;
        const today = this.getToday();
        if (lastDay != today) {
            lastDay = today;
            wx.setStorageSync('lastDay', lastDay);
            this.globalData.newDay = true;
        }
    },
    random(len, start, end) {
        var arr = [];

        function _inner(start, end) {
            var span = end - start;
            return parseInt(Math.random() * span + start)
        }
        while (arr.length < len) {
            var num = _inner(start, end);
            if (arr.indexOf(num) == -1) {
                arr.push(num);
            }
        }
        return arr;
    }

})